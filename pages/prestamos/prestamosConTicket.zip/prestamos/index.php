<?php

// Mostramos el contenido html del head
require_once(__DIR__ . "/../view/head.php");

// Mostramos el contenido html de la página
require(__DIR__ . "/view/index.php");

// Mostramos el contenido html del footer.
require_once(__DIR__ . "/../view/footer.php");